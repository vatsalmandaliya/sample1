var vatsal = require (index)
console.log (vatsal)